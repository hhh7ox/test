package com.qf.impl;

import com.qf.UserService;

/**
 * create by hhh7ox on 2022/5/17 21:32
 */
public class UserServiceImpl implements UserService {

    @Override
    public void addUser() {
        System.out.println("添加了用户");
    }
}
