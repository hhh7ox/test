package com.qf;

/**
 * create by hhh7ox on 2022/5/17 21:32
 */
public interface UserService {
    public void addUser();
}
