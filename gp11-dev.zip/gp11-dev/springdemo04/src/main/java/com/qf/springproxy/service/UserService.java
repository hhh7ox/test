package com.qf.springproxy.service;

/**
 * create by hhh7ox on 2022/5/18 17:31
 */
public interface UserService {
    void addUser(String name);
    String modifyUser(String name);
}
