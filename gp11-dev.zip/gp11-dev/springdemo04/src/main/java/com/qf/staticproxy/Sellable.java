package com.qf.staticproxy;

/**
 * create by hhh7ox on 2022/5/18 17:19
 */
public interface Sellable {
    void qht();
    void jq();
}
