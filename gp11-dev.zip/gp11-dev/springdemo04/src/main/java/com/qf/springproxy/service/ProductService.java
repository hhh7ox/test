package com.qf.springproxy.service;

/**
 * create by hhh7ox on 2022/5/18 17:57
 */
public interface ProductService {
    String buyProduct(Double price);
}
