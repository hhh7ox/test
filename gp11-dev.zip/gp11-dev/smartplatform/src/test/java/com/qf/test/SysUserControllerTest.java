package com.qf.test;

import com.qf.pojo.SysLoginInfo;
import com.qf.pojo.SysUserOnline;
import com.qf.service.SysLoginInfoService;
import com.qf.service.SysUserInfoService;
import com.qf.service.SysUserOnlineService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.Date;

/**
 * create by hhh7ox on 2022/5/25 17:28
 */

@RunWith(SpringJUnit4ClassRunner.class)//以spring的方式运行
@ContextConfiguration({"classpath:spring/applicationContext.xml", "classpath:spring/applicationContext-mybatis.xml"})
@WebAppConfiguration//web程序
public class SysUserControllerTest {

    private SysUserInfoService userInfoService;
    private SysLoginInfoService sysLoginInfoService;
    private SysUserOnlineService sysUserOnlineService;

    @Autowired
    public void setSysUserOnlineService(SysUserOnlineService sysUserOnlineService) {
        this.sysUserOnlineService = sysUserOnlineService;
    }

    @Autowired
    public void setUserInfoService(SysUserInfoService userInfoService) {
        this.userInfoService = userInfoService;
    }

    @Autowired
    public void setSysLoginInfoService(SysLoginInfoService sysLoginInfoService) {
        this.sysLoginInfoService = sysLoginInfoService;
    }

    @Test
    public void testLoginInfoMapper(){
        SysLoginInfo sysLoginInfo = new SysLoginInfo(null, "lisi", "0:0:0:0:0:0:0:1", null,  "More-Info: apifox/1.0.0 (https://www.apifox.cn)",  "apifox/1.0.0 (https://www.apifox.cn)", "1", "登录成功", new Date());
        sysLoginInfoService.increaseSysLoginInfo(sysLoginInfo);
    }

    @Test
    public void testUserLoginUpdateMapper() {
        SysLoginInfo sysLoginInfo = new SysLoginInfo(null, "lisi", "0:0:0:0:0:0:0:1", null,  "More-Info: apifox/1.0.0 (https://www.apifox.cn)",  "apifox/1.0.0 (https://www.apifox.cn)", "1", "登录成功", new Date());
        userInfoService.updateSysUserInfo(sysLoginInfo);
    }

    @Test
    public void testSysUserOnlineMapper() {
        SysUserOnline sysUserOnline = new SysUserOnline("1235699","lisi","192.168.0.1","beijing",null,null,null,null,null,null);
        sysUserOnlineService.increaseOrModifySysUserOnline(sysUserOnline);
    }


}
