package com.qf.test;

import com.qf.dto.SysUserDto;
import com.qf.utils.JudgeUtils;
import com.qf.utils.RandomUtils;
import org.junit.Test;

/**
 * create by hhh7ox on 2022/5/26 12:00
 */

public class UtilsTest {
    @Test
    public void testJudgeUtils(){
        SysUserDto userDto = new SysUserDto("zhangsan","123","zhangzhang","123321231","zhang@zhang.com",1L);
        System.out.println(JudgeUtils.isEmpty(userDto));
    }

    @Test
    public void testRandomUtils(){
        String[] strings = RandomUtils.getMD5WithRandomSalt("123456");
        System.out.println(strings[0]+" : "+strings[1]);
        System.out.println(RandomUtils.getMD5WithSalt("123456","COc5syMjL2"));
//898068504c57f03a948a7c582f51218f
    }
}
