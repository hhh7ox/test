package com.qf.service;

import com.qf.pojo.SysLoginInfo;

/**
 * create by hhh7ox on 2022/5/26 17:45
 */
public interface SysLoginInfoService {
    void increaseSysLoginInfo(SysLoginInfo sysLoginInfo);
}
