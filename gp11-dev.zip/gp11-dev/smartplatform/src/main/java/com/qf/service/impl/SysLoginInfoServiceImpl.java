package com.qf.service.impl;

import com.qf.mapper.SysLoginInfoMapper;
import com.qf.pojo.SysLoginInfo;
import com.qf.service.SysLoginInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * create by hhh7ox on 2022/5/26 17:46
 */

@Service
@Transactional
public class SysLoginInfoServiceImpl implements SysLoginInfoService {
    private SysLoginInfoMapper sysLoginInfoMapper;

    @Autowired
    public void setSysLoginInfoMapper(SysLoginInfoMapper sysLoginInfoMapper) {
        this.sysLoginInfoMapper = sysLoginInfoMapper;
    }

    @Override
    public void increaseSysLoginInfo(SysLoginInfo sysLoginInfo) {
        System.out.println("---service ----"+sysLoginInfo);
        sysLoginInfoMapper.insertSysLoginInfo(sysLoginInfo);
        System.out.println("sysLoginInfoMapper.insertSysLoginInfo执行");
    }

}
