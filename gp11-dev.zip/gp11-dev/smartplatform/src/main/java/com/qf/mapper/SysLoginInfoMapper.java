package com.qf.mapper;

import com.qf.pojo.SysLoginInfo;
import org.apache.ibatis.annotations.Param;

/**
 * create by hhh7ox on 2022/5/26 17:49
 */
public interface SysLoginInfoMapper {

    void insertSysLoginInfo(@Param("sysLoginInfo") SysLoginInfo sysLoginInfo);
}
