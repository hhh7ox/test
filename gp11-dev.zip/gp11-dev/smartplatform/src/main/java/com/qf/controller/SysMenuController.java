package com.qf.controller;

import com.qf.constants.ResultCode;
import com.qf.dto.R;
import com.qf.pojo.SysMenu;
import com.qf.service.SysMenuService;
import com.qf.utils.RUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.xml.transform.Result;
import java.util.List;

/**
 * create by hhh7ox on 2022/6/8 20:53
 */

@RestController
@RequestMapping("/menus")
public class SysMenuController {
    private SysMenuService sysMenuService;

    @Autowired
    public void setSysMenuService(SysMenuService sysMenuService) {
        this.sysMenuService = sysMenuService;
    }

    @GetMapping("/menus")
    public R showMenus(){
        List<SysMenu> sysMenuList = sysMenuService.queryAll();
        return RUtils.setResult(ResultCode.QUERY_SUCCESS,"查询成功",sysMenuList);
    }
}
