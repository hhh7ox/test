package com.qf.mapper;

import com.qf.pojo.SysCategory;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;

/**
 * create by hhh7ox on 2022/6/6 11:08
 */
public interface SysCategoryMapper {

    void insertSysCategory(SysCategory sysCategory);

    @Select("select * from sys_category")
    List<SysCategory> selectAll();

    void deleteByCid(@Param("cId") Long cId, @Param("updateTime") Date updateTime, @Param("updateBy") String updateBy);

    void deleteByCids(List<Long> cIds, Date date, String name);

    void updateStatusByIds(List<Long> cIds, Date date, String name);

    String selectTxCommandByCid(Long cId);
}
