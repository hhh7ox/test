package com.qf.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.qf.cache.SysCategoryCache;
import com.qf.cache.SysSceneCache;
import com.qf.constants.ResultCode;
import com.qf.dto.SysDeviceDto;
import com.qf.event.SysDeviceCommandEvent;
import com.qf.exceptions.data.DataIllegalException;
import com.qf.mapper.SysDeviceMapper;
import com.qf.pojo.SysCategory;
import com.qf.pojo.SysDevice;
import com.qf.pojo.SysScene;
import com.qf.pojo.SysUserInfo;
import com.qf.service.SysCategoryService;
import com.qf.service.SysDeviceService;
import com.qf.utils.JudgeUtils;
import com.qf.utils.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * create by hhh7ox on 2022/6/7 16:47
 */
@Service
public class SysDeviceServiceImpl implements SysDeviceService {
    private SysDeviceMapper sysDeviceMapper;
    private SysCategoryCache sysCategoryCache;
    private SysSceneCache sysSceneCache;
    private ApplicationContext context;
    private SysCategoryService sysCategoryService;
    private ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public void setSysCategoryService(SysCategoryService sysCategoryService) {
        this.sysCategoryService = sysCategoryService;
    }

    @Autowired
    public void setContext(ApplicationContext context) {
        this.context = context;
    }

    @Autowired
    public void setSysSceneCache(SysSceneCache sysSceneCache) {
        this.sysSceneCache = sysSceneCache;
    }

    @Autowired
    public void setSysCategoryCache(SysCategoryCache sysCategoryCache) {
        this.sysCategoryCache = sysCategoryCache;
    }

    @Autowired
    public void setSysDeviceMapper(SysDeviceMapper sysDeviceMapper) {
        this.sysDeviceMapper = sysDeviceMapper;
    }

    @Override
    public void increaseSysDevice(SysDeviceDto sysDeviceDto) {
        Assert.notNull(sysDeviceDto,()->{
            throw new DataIllegalException("设备信息为空 添加失败", ResultCode.INCREASE_FAIL);
        });
        Assert.isTrue(!JudgeUtils.isEmpty(sysDeviceDto),()->{
            throw new DataIllegalException("设备属性为空 添加失败",ResultCode.DATA_ILLEGAL_NULL);
        });

        Assert.notNull((sysCategoryCache.getSysCategoryByCid(sysDeviceDto.getCategoryId())),()->{
            throw new DataIllegalException("分类不存在 添加失败",ResultCode.DATA_ILLEGAL_NULL);
        });
        sysDeviceMapper.insertSysDevice(sysDeviceDto);
    }

    @Override
    public void modifySysDeviceStatus(String deviceId,Integer status) {
        Assert.isTrue(!JudgeUtils.isEmpty(deviceId),()->{
            throw new DataIllegalException("设备不存在",ResultCode.DATA_ILLEGAL_NULL);
        });
        Assert.isTrue(!JudgeUtils.isEmpty(status),()->{
            throw new DataIllegalException("状态为空",ResultCode.DATA_ILLEGAL_NULL);
        });
        sysDeviceMapper.updateSysDeviceStatus(deviceId,status);
    }

    @Override
    public SysDevice querySysDeviceById(String deviceId) {
        Assert.isTrue(!JudgeUtils.isEmpty(deviceId),()->{
            throw new DataIllegalException("设备id为空",ResultCode.DATA_ILLEGAL_NULL);
        });
        SysDevice sysDevice = sysDeviceMapper.selectSysDeviceById(deviceId);
        Assert.notNull(sysDevice,()->{
            throw new DataIllegalException("设备不存在",ResultCode.DATA_ILLEGAL_NULL);
        });
        return sysDevice;
    }

    @Override
    public void bindUserAndScene(SysDevice sysDevice,Long sceneId) {
        Assert.isTrue(JudgeUtils.isEmpty(sysDevice,"bindUserId"),()->{
            throw new DataIllegalException("已有用户绑定 请先解除绑定",ResultCode.DATA_ILLEGAL_REPEAT);
        });
        SysUserInfo sysUserInfo = SecurityUtils.getSysUserInfo();
        Assert.notNull(sysUserInfo,()->{
            throw new DataIllegalException("用户为空 请登录",ResultCode.DATA_ILLEGAL_NULL);
        });
        List<SysScene> sysSceneList = sysSceneCache.getUserSceneCache().getUnchecked(sysUserInfo.getUId());
        SysScene sysScene = sysSceneList.stream().filter(sysScene1 -> sysScene1.getSceneId() == sceneId).findAny().get();
        Assert.notNull(sysScene,()->{
            throw new DataIllegalException("场景不存在 请重新选择",ResultCode.DATA_ILLEGAL_NULL);
        });
        sysDevice.setBindUserId(sysUserInfo.getUId());
        sysDevice.setBindTime(new Date());
        sysDevice.setSceneId(sysScene.getSceneId());
        sysDeviceMapper.updateSysDeviceUserAndScene(sysDevice);
    }

    @Override
    public PageInfo<SysDevice> queryAll(int pageSize, int pageNum) {
//        PageHelper.startPage(pageSize,pageNum);
        List<SysDevice> sysDeviceList = sysDeviceMapper.selectAll();
        PageInfo<SysDevice> pageInfo = new PageInfo<>(sysDeviceList);
        return pageInfo;
    }

    @Override
    public void sendCommand(String deviceId, String command) {
        SysDevice sysDevice = querySysDeviceById(deviceId);
        String realCommand = null;
//      {"open":{"type":1,"command":"0"},"close":{"type":1,"command":"1"},"color":{"type":2,"command":"2"}}
        Assert.notNull(sysDevice, () -> {
            throw new DataIllegalException(ResultCode.DATA_ILLEGAL_NULL, "设备传参为空");
        });
        Long cId = sysCategoryCache.getSysCategoryList(true).stream().filter(sysCategory ->
                sysCategory.getCId() == sysDevice.getCategoryId()).findFirst().get().getCId();
        try {
            Map realCommandMap = objectMapper.readValue(sysCategoryService.queryTxCommandByCid(cId), Map.class);
            realCommand = ((Map<Long, String>) realCommandMap.get(command)).get("command");
        } catch (JsonProcessingException e) {
            throw new DataIllegalException(ResultCode.DATA_ILLEGAL_NULL,"未找到设备种类");
        }

        context.publishEvent(new SysDeviceCommandEvent(deviceId,realCommand));
    }


}
