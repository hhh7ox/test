package com.qf.mapper;

import com.qf.dto.SysDeviceDto;
import com.qf.pojo.SysDevice;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * create by hhh7ox on 2022/6/7 16:46
 */
public interface SysDeviceMapper {
    void insertSysDevice(SysDeviceDto sysDeviceDto);

    void updateSysDeviceStatus(@Param("deviceId") String deviceId, @Param("status") Integer status);

    void updateSysDeviceUserAndScene(SysDevice sysDevice);

    SysDevice selectSysDeviceById(@Param("deviceId") String deviceId);

    List<SysDevice> selectAll();

}
