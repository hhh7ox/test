package com.qf.service;

import com.qf.dto.SysUserDto;
import com.qf.pojo.SysLoginInfo;
import com.qf.pojo.SysUserInfo;

/**
 * create by hhh7ox on 2022/5/25 19:44
 */
public interface SysUserInfoService {
    void increaseSysUserInfo(SysUserDto sysUserDto);
    SysUserInfo querySysUserInfo(SysUserDto sysUserDto);
    void updateSysUserInfo(SysLoginInfo sysLoginInfo);

}
