package com.qf.pojo;


import java.util.Date;

public class SysUserInfo {

  private Long uId;
  private String username;
  private String password;
  private String pwdSalt;
  private String name;
  private String phone;
  private String email;
  private Long sex;
  private String avator;
  private String info;
  private Long type;
  private Long status;
  private java.util.Date currentLogin;
  private java.util.Date lastLogin;
  private String currentLoginIp;
  private String lastLoginIp;
  private java.util.Date createTime;
  private String createBy;
  private java.util.Date updateTime;
  private String updateBy;
  private String remark;

  public SysUserInfo() {
  }

  public SysUserInfo(Long uId, String username, String password, String pwdSalt, String name, String phone, String email, Long sex, String avator, String info, Long type, Long status, Date currentLogin, Date lastLogin, String currentLoginIp, String lastLoginIp, Date createTime, String createBy, Date updateTime, String updateBy, String remark) {
    this.uId = uId;
    this.username = username;
    this.password = password;
    this.pwdSalt = pwdSalt;
    this.name = name;
    this.phone = phone;
    this.email = email;
    this.sex = sex;
    this.avator = avator;
    this.info = info;
    this.type = type;
    this.status = status;
    this.currentLogin = currentLogin;
    this.lastLogin = lastLogin;
    this.currentLoginIp = currentLoginIp;
    this.lastLoginIp = lastLoginIp;
    this.createTime = createTime;
    this.createBy = createBy;
    this.updateTime = updateTime;
    this.updateBy = updateBy;
    this.remark = remark;
  }

  public Long getUId() {
    return uId;
  }

  public void setUId(Long uId) {
    this.uId = uId;
  }


  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }


  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }


  public String getPwdSalt() {
    return pwdSalt;
  }

  public void setPwdSalt(String pwdSalt) {
    this.pwdSalt = pwdSalt;
  }


  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }


  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }


  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }


  public Long getSex() {
    return sex;
  }

  public void setSex(Long sex) {
    this.sex = sex;
  }


  public String getAvator() {
    return avator;
  }

  public void setAvator(String avator) {
    this.avator = avator;
  }


  public String getInfo() {
    return info;
  }

  public void setInfo(String info) {
    this.info = info;
  }


  public Long getType() {
    return type;
  }

  public void setType(Long type) {
    this.type = type;
  }


  public Long getStatus() {
    return status;
  }

  public void setStatus(Long status) {
    this.status = status;
  }


  public java.util.Date getCurrentLogin() {
    return currentLogin;
  }

  public void setCurrentLogin(java.util.Date currentLogin) {
    this.currentLogin = currentLogin;
  }


  public java.util.Date getLastLogin() {
    return lastLogin;
  }

  public void setLastLogin(java.util.Date lastLogin) {
    this.lastLogin = lastLogin;
  }


  public String getCurrentLoginIp() {
    return currentLoginIp;
  }

  public void setCurrentLoginIp(String currentLoginIp) {
    this.currentLoginIp = currentLoginIp;
  }


  public String getLastLoginIp() {
    return lastLoginIp;
  }

  public void setLastLoginIp(String lastLoginIp) {
    this.lastLoginIp = lastLoginIp;
  }


  public java.util.Date getCreateTime() {
    return createTime;
  }

  public void setCreateTime(java.util.Date createTime) {
    this.createTime = createTime;
  }


  public String getCreateBy() {
    return createBy;
  }

  public void setCreateBy(String createBy) {
    this.createBy = createBy;
  }


  public java.util.Date getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(java.util.Date updateTime) {
    this.updateTime = updateTime;
  }


  public String getUpdateBy() {
    return updateBy;
  }

  public void setUpdateBy(String updateBy) {
    this.updateBy = updateBy;
  }


  public String getRemark() {
    return remark;
  }

  public void setRemark(String remark) {
    this.remark = remark;
  }

  @Override
  public String toString() {
    return "SysUserInfo{" +
            "uId=" + uId +
            ", username='" + username + '\'' +
            ", password='" + password + '\'' +
            ", pwdSalt='" + pwdSalt + '\'' +
            ", name='" + name + '\'' +
            ", phone='" + phone + '\'' +
            ", email='" + email + '\'' +
            ", sex=" + sex +
            ", avator='" + avator + '\'' +
            ", info='" + info + '\'' +
            ", type=" + type +
            ", status=" + status +
            ", currentLogin=" + currentLogin +
            ", lastLogin=" + lastLogin +
            ", currentLoginIp='" + currentLoginIp + '\'' +
            ", lastLoginIp='" + lastLoginIp + '\'' +
            ", createTime=" + createTime +
            ", createBy='" + createBy + '\'' +
            ", updateTime=" + updateTime +
            ", updateBy='" + updateBy + '\'' +
            ", remark='" + remark + '\'' +
            '}';
  }
}
