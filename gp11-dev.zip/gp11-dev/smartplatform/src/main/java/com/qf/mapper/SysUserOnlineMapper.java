package com.qf.mapper;

import com.qf.pojo.SysUserOnline;
import org.apache.ibatis.annotations.Param;

/**
 * create by hhh7ox on 2022/5/26 17:49
 */

public interface SysUserOnlineMapper {
    SysUserOnline selectByLoginName(@Param("sysUserOnline") SysUserOnline sysUserOnline);

    void insertSysUserOnline(@Param("sysUserOnline") SysUserOnline sysUserOnline);

    void updateSysUserOnline(@Param("sysUserOnline")SysUserOnline sysUserOnline);
}
