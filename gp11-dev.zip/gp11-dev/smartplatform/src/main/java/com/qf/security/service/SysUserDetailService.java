package com.qf.security.service;

import com.qf.dto.SysUserDto;
import com.qf.mapper.SysUserInfoMapper;
import com.qf.pojo.MyBaseUser;
import com.qf.pojo.SysUserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.ArrayList;

/**
 * create by hhh7ox on 2022/6/10 15:52
 */

@Service
public class SysUserDetailService implements UserDetailsService {
    private SysUserInfoMapper sysUserInfoMapper;

    @Autowired
    public void setSysUserInfoMapper(SysUserInfoMapper sysUserInfoMapper) {
        this.sysUserInfoMapper = sysUserInfoMapper;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        servletRequestAttributes.getRequest().setAttribute("username",username);
        Assert.notNull(username,()->{
            throw new UsernameNotFoundException("用户名或密码错误");
        });
        SysUserInfo sysUserInfo = sysUserInfoMapper.selectByUsername(new SysUserDto(username, null, null, null, null, null));
        MyBaseUser user = new MyBaseUser(username,sysUserInfo.getPassword(),new ArrayList<>());
        return user;
    }
}
