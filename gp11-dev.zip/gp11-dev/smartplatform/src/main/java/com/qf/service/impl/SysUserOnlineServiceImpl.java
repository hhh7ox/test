package com.qf.service.impl;

import com.qf.mapper.SysUserOnlineMapper;
import com.qf.pojo.SysUserOnline;
import com.qf.service.SysUserOnlineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * create by hhh7ox on 2022/5/26 17:47
 */
@Service
@Transactional
public class SysUserOnlineServiceImpl implements SysUserOnlineService {
    private SysUserOnlineMapper sysUserOnlineMapper;

    @Autowired
    public void setSysUserOnlineMapper(SysUserOnlineMapper sysUserOnlineMapper) {
        this.sysUserOnlineMapper = sysUserOnlineMapper;
    }

    @Override
    public void increaseOrModifySysUserOnline(SysUserOnline sysUserOnline) {
        SysUserOnline sysUserOnlineOld = null;
        sysUserOnlineOld = sysUserOnlineMapper.selectByLoginName(sysUserOnline);
        if (sysUserOnlineOld==null){
            sysUserOnlineMapper.insertSysUserOnline(sysUserOnline);
        }else{
            sysUserOnlineMapper.updateSysUserOnline(sysUserOnline);
        }
    }
}
