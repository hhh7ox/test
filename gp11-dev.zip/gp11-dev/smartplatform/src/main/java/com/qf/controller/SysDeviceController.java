package com.qf.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageInfo;
import com.qf.cache.SysCategoryCache;
import com.qf.constants.ResultCode;
import com.qf.dto.R;
import com.qf.dto.SysDeviceDto;
import com.qf.exceptions.data.DataIllegalException;
import com.qf.pojo.SysCategory;
import com.qf.pojo.SysDevice;
import com.qf.service.SysCategoryService;
import com.qf.service.SysDeviceService;
import com.qf.utils.RUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.stream.Collectors;

/**
 * create by hhh7ox on 2022/6/7 16:48
 */

@RestController
@RequestMapping("/device")
public class SysDeviceController {
    private SysDeviceService sysDeviceService;
    private SysCategoryService sysCategoryService;


    @Autowired
    public void setSysCategoryService(SysCategoryService sysCategoryService) {
        this.sysCategoryService = sysCategoryService;
    }

    @Autowired
    public void setSysDeviceService(SysDeviceService sysDeviceService) {
        this.sysDeviceService = sysDeviceService;
    }

    @PostMapping("/increase")
    public R increase(@RequestBody SysDeviceDto sysDeviceDto) {
        sysDeviceService.increaseSysDevice(sysDeviceDto);
        return RUtils.setResult(ResultCode.INCREASE_SUCCESS, "添加设备成功", null);
    }

    @PostMapping("/buy")
    public R buyDevice(@RequestParam String deviceId) {
        sysDeviceService.modifySysDeviceStatus(deviceId, 1);
        return RUtils.setResult(ResultCode.MODIFY_SUCCESS, "购买设备成功 状态码改为 1", null);
    }

    @PostMapping("/bind")
    public R bindUserAndScene(@RequestParam String deviceId, @RequestParam Long sceneId) {
        SysDevice sysDevice = sysDeviceService.querySysDeviceById(deviceId);
        sysDeviceService.bindUserAndScene(sysDevice, sceneId);
        return RUtils.setResult(ResultCode.MODIFY_SUCCESS, "绑定成功", null);
    }

    @GetMapping("/show")
    public R showDevice(@RequestParam("limit") int pageSize, @RequestParam("page") int pageNum) {
        PageInfo<SysDevice> pageInfo = sysDeviceService.queryAll(pageSize, pageNum);
        return RUtils.setResult(ResultCode.QUERY_SUCCESS, "查询分类成功", pageInfo);

    }

    @PostMapping("/sendCommand/{deviceId}/{command}")
    public R sendCommand(@PathVariable("deviceId") String deviceId, @PathVariable("command") String command) {
        sysDeviceService.sendCommand(deviceId,command);
        return RUtils.setResult(ResultCode.QUERY_SUCCESS, "发送命令成功", null);

    }


}
