package com.qf.cache;

import com.qf.event.SysCategoryChangeEvent;
import com.qf.mapper.SysCategoryMapper;
import com.qf.pojo.SysCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * create by hhh7ox on 2022/6/6 19:22
 */

@Component
public class SysCategoryCache {
    private SysCategoryMapper sysCategoryMapper;
    private List<SysCategory> sysCategoryList = new ArrayList<>();
    private List<SysCategory> validSysCategoryList = new ArrayList<>();
    private Map<Long, SysCategory> sysCategoryMap = new HashMap<>();

    @Autowired
    public void setSysCategoryMapper(SysCategoryMapper sysCategoryMapper) {
        this.sysCategoryMapper = sysCategoryMapper;
    }

    @PostConstruct
    public void init() {
        List<SysCategory> sysCategories = sysCategoryMapper.selectAll();
        sysCategoryList.clear();
        sysCategoryList.addAll(sysCategories);
        List<SysCategory> validSysCategories = sysCategories.stream().filter(sysCategory -> sysCategory.getStatus() == 1).collect(Collectors.toList());
        validSysCategoryList.clear();
        validSysCategoryList.addAll(validSysCategories);
        Map<Long, SysCategory> sysCategoriesMap = validSysCategories.stream().collect(Collectors.toMap(SysCategory::getCId, sysCategory -> sysCategory));
        sysCategoryMap.clear();
        sysCategoryMap.putAll(sysCategoriesMap);
    }

    public List<SysCategory> getSysCategoryList(boolean isValid) {
        if (isValid) {
            return validSysCategoryList;
        }
        return sysCategoryList;
    }

    public SysCategory getSysCategoryByCid(Long cId){
        return sysCategoryMap.get(cId);
    }

    @EventListener
    @Async
    public void onEvent(SysCategoryChangeEvent sysCategoryChangeEvent) {
        init();
    }
}
