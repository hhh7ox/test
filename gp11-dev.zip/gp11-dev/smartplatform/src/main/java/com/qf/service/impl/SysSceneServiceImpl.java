package com.qf.service.impl;

import com.qf.cache.SysSceneCache;
import com.qf.constants.ResultCode;
import com.qf.exceptions.data.DataIllegalException;
import com.qf.mapper.SysSceneMapper;
import com.qf.pojo.SysScene;
import com.qf.pojo.SysUserInfo;
import com.qf.service.SysSceneService;
import com.qf.utils.JudgeUtils;
import com.qf.utils.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * create by hhh7ox on 2022/6/7 19:27
 */
@Service
public class SysSceneServiceImpl implements SysSceneService {
    private SysSceneMapper sysSceneMapper;
    private SysSceneCache sysSceneCache;

    @Autowired
    public void setSysSceneCache(SysSceneCache sysSceneCache) {
        this.sysSceneCache = sysSceneCache;
    }

    @Autowired
    public void setSysSceneMapper(SysSceneMapper sysSceneMapper) {
        this.sysSceneMapper = sysSceneMapper;
    }

    @Override
    public void increaseSysScene(SysScene sysScene) {
        Assert.isTrue(!JudgeUtils.isEmpty(sysScene,"sceneName"),()->{
            throw new DataIllegalException("场景名称为空", ResultCode.DATA_ILLEGAL_NULL);
        });
        SysUserInfo sysUserInfo = SecurityUtils.getSysUserInfo();
        sysScene.setCreateTime(new Date());
        sysScene.setCreateBy(sysUserInfo.getUId());
        List<SysScene> sysSceneList = sysSceneCache.getUserSceneCache().getUnchecked(sysUserInfo.getUId());
        List<SysScene> result = sysSceneList.stream().filter(sysScene1 -> sysScene1.getSceneName().equals(sysScene.getSceneName())).collect(Collectors.toList());
        Assert.isTrue(result.size()==0,()->{
            throw new DataIllegalException("场景名称重复",ResultCode.DATA_ILLEGAL_REPEAT);
        });

        sysScene.setStatus(0L);
        sysSceneMapper.insertSysScene(sysScene);
    }
}
