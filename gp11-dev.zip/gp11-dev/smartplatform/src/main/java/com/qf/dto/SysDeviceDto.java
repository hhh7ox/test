package com.qf.dto;

/**
 * create by hhh7ox on 2022/6/7 16:50
 */

public class SysDeviceDto {
    private String deviceId;
    private String deviceName;
    private Long categoryId;

    public SysDeviceDto(String deviceId, String deviceName, Long categoryId) {
        this.deviceId = deviceId;
        this.deviceName = deviceName;
        this.categoryId = categoryId;
    }

    public SysDeviceDto() {
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    @Override
    public String toString() {
        return "SysDeviceDto{" +
                "deviceId='" + deviceId + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", categoryId=" + categoryId +
                '}';
    }
}
