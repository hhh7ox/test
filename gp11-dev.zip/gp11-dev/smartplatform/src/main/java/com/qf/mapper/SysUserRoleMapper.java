package com.qf.mapper;

import java.util.List;

/**
 * create by hhh7ox on 2022/6/11 17:21
 */
public interface SysUserRoleMapper {
    List<Long> selectRoleIdByUserId(Long userId);
}
