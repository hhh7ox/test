package com.qf.service.impl;

import com.qf.mapper.SysMenuMapper;
import com.qf.pojo.SysMenu;
import com.qf.service.SysMenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * create by hhh7ox on 2022/6/8 20:55
 */
@Service
public class SysMenuServiceImpl implements SysMenuService {
    private SysMenuMapper sysMenuMapper;

    @Autowired
    public void setSysMenuMapper(SysMenuMapper sysMenuMapper) {
        this.sysMenuMapper = sysMenuMapper;
    }

    @Override
    public List<SysMenu> queryAll() {
        List<SysMenu> sysMenuList = sysMenuMapper.selectAll();
        return sysMenuList.stream()
                .filter(sysMenu -> sysMenu.getMenuId() == 4L || sysMenu.getMenuId() == 6L)
                .collect(Collectors.toList());
    }
}
