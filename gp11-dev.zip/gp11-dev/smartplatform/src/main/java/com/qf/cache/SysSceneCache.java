package com.qf.cache;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.qf.mapper.SysSceneMapper;
import com.qf.pojo.SysScene;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * create by hhh7ox on 2022/6/7 19:44
 */

@EnableAsync
@Component
public class SysSceneCache {
   private SysSceneMapper sysSceneMapper;

    @Autowired
    public void setSysSceneMapper(SysSceneMapper sysSceneMapper) {
        this.sysSceneMapper = sysSceneMapper;
    }

    LoadingCache<Long, List<SysScene>> userSceneCache = CacheBuilder.newBuilder()
            .expireAfterAccess(15, TimeUnit.MINUTES)
            .build(new CacheLoader<Long, List<SysScene>>() {
                @Override
                public List<SysScene> load(Long uId) throws Exception {
                    return sysSceneMapper.selectAllByUid(uId);
                }
            });


    public LoadingCache<Long, List<SysScene>> getUserSceneCache() {
        return userSceneCache;
    }

}
