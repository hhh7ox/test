package com.qf.exceptions.login;

import com.qf.exceptions.BaseException;

/**
 * create by hhh7ox on 2022/5/26 10:50
 */
public class LoginSysUserInfoIllegalException extends BaseException {
    public LoginSysUserInfoIllegalException(String message, String code) {
        super(message, code);
    }
}
