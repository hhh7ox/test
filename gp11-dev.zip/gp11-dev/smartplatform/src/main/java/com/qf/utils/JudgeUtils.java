package com.qf.utils;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * create by hhh7ox on 2022/5/25 19:24
 */
public class JudgeUtils {

    public static boolean isEmpty(String str) {
        return str.isEmpty() || str.trim().length() == 0;
    }

    public static boolean isEmpty(Object obj) {
        List<Object> params = new ArrayList<>();
        for (Field declaredField : obj.getClass().getDeclaredFields()) {
            params.add(declaredField.getName());
        }
        return isEmpty(obj, params.toArray());
    }

    public static boolean isEmpty(Object obj, Object... params) {
        boolean flag = false;
        Class<?> objClass = obj.getClass();
        for (int i = 0; i < params.length; i++) {
            try {
                String filedName = objClass.getDeclaredField(params[i].toString()).getName();
                Object value = new PropertyDescriptor(filedName, objClass).getReadMethod().invoke(obj);
                if (value == null) {
                    flag = true;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return flag;
    }

}
