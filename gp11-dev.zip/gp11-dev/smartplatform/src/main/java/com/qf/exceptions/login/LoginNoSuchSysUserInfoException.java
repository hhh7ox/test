package com.qf.exceptions.login;

import com.qf.exceptions.BaseException;

/**
 * create by hhh7ox on 2022/5/26 10:51
 */
public class LoginNoSuchSysUserInfoException extends BaseException {
    public LoginNoSuchSysUserInfoException(String message, String code) {
        super(message, code);
    }
}
