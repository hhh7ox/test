package com.qf.exceptions.regist;

import com.qf.exceptions.BaseException;

/**
 * create by hhh7ox on 2022/5/25 21:14
 */
public class RegistSysUserInfoIllegalException extends BaseException {
    public RegistSysUserInfoIllegalException(String message, String code) {
        super(message, code);
    }
}
