package com.qf.utils;

import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * create by hhh7ox on 2022/5/25 19:24
 */
public class RandomUtils {
    static String defaultSalt = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567890";
    public static String[] getMD5WithRandomSalt(String str){
        StringBuilder stringBuilder = new StringBuilder();
        String[] salts = defaultSalt.split("");
        List<String> saltList = Arrays.asList(salts);
        Collections.shuffle(saltList);
        for (int i = 0; i < 10; i++) {
            stringBuilder.append(saltList.get(new Random().nextInt(saltList.size())));
        }
        String randomSalt = stringBuilder.toString();
        String [] result = {DigestUtils.md5DigestAsHex((str+randomSalt).getBytes(StandardCharsets.UTF_8)),randomSalt};
        return result;
    }

    public static String getMD5WithSalt(String str, String salt){
        return DigestUtils.md5DigestAsHex((str+salt).getBytes(StandardCharsets.UTF_8));
    }


}
