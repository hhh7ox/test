package com.qf.mapper;

import com.qf.dto.SysUserDto;
import com.qf.pojo.SysLoginInfo;
import com.qf.pojo.SysUserInfo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * create by hhh7ox on 2022/5/25 19:40
 */

public interface SysUserInfoMapper {

    @Select("select * from sys_user_info where username=#{username}")
    SysUserInfo selectByUsername(SysUserDto sysUserDto);

    @Select("select * from sys_user_info where username=#{phone}")
    SysUserInfo selectByPhone(SysUserDto sysUserDto);

    @Select("select * from sys_user_info where username=#{email}")
    SysUserInfo selectByEmail(SysUserDto sysUserDto);


    void insertSysUser(@Param("sysUser") SysUserInfo sysUser);

    void updateSysUserInfoByUsername(@Param("sysLoginInfo") SysLoginInfo sysLoginInfo);
}
