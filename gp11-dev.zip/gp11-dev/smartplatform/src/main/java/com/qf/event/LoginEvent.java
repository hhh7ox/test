package com.qf.event;

/**
 * create by hhh7ox on 2022/5/26 17:00
 */
public class LoginEvent {
    private LoginType loginType;
    private String username;

    public LoginEvent(LoginType loginType, String username) {
        this.loginType = loginType;
        this.username = username;
    }

    public LoginEvent() {
    }

    public LoginType getLoginType() {
        return loginType;
    }

    public void setLoginType(LoginType loginType) {
        this.loginType = loginType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public enum LoginType{
        SUCCESS,FAIL
    }
}
