package com.qf.pojo;


import java.util.Date;

public class SysCategory {

    private Long cId;
    private String categoryName;
    private String txCommand;
    private String rxCommand;
    private String commandName;
    private Long status;
    private java.util.Date createTime;
    private String createBy;
    private java.util.Date updateTime;
    private String updateBy;

    public SysCategory() {
    }

    public SysCategory(Long cId, String categoryName, String txCommand, String rxCommand, String commandName, Long status, Date createTime, String createBy, Date updateTime, String updateBy) {
        this.cId = cId;
        this.categoryName = categoryName;
        this.txCommand = txCommand;
        this.rxCommand = rxCommand;
        this.commandName = commandName;
        this.status = status;
        this.createTime = createTime;
        this.createBy = createBy;
        this.updateTime = updateTime;
        this.updateBy = updateBy;
    }

    public Long getCId() {
        return cId;
    }

    public void setCId(Long cId) {
        this.cId = cId;
    }


    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }


    public String getTxCommand() {
        return txCommand;
    }

    public void setTxCommand(String txCommand) {
        this.txCommand = txCommand;
    }


    public String getRxCommand() {
        return rxCommand;
    }

    public void setRxCommand(String rxCommand) {
        this.rxCommand = rxCommand;
    }


    public String getCommandName() {
        return commandName;
    }

    public void setCommandName(String commandName) {
        this.commandName = commandName;
    }


    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }


    public java.util.Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(java.util.Date createTime) {
        this.createTime = createTime;
    }


    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }


    public java.util.Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(java.util.Date updateTime) {
        this.updateTime = updateTime;
    }


    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    @Override
    public String toString() {
        return "SysCategory{" +
                "cId=" + cId +
                ", categoryName='" + categoryName + '\'' +
                ", txCommand='" + txCommand + '\'' +
                ", rxCommand='" + rxCommand + '\'' +
                ", commandName='" + commandName + '\'' +
                ", status=" + status +
                ", createTime=" + createTime +
                ", createBy='" + createBy + '\'' +
                ", updateTime=" + updateTime +
                ", updateBy='" + updateBy + '\'' +
                '}';
    }
}
