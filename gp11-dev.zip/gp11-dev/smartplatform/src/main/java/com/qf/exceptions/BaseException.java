package com.qf.exceptions;

/**
 * create by hhh7ox on 2022/5/25 21:09
 */
public class BaseException extends RuntimeException {
    private String code;

    public BaseException(String message, String code) {
        super(message);
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
