package com.qf.controller;

import com.github.pagehelper.PageInfo;
import com.qf.constants.ResultCode;
import com.qf.dto.R;
import com.qf.pojo.SysCategory;
import com.qf.service.SysCategoryService;
import com.qf.utils.RUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * create by hhh7ox on 2022/6/6 14:15
 */

@RestController
@RequestMapping("/sysCategory")
public class SysCategoryController {
    private SysCategoryService sysCategoryService;

    @Autowired
    public void setSysCategoryService(SysCategoryService sysCategoryService) {
        this.sysCategoryService = sysCategoryService;
    }

    @PostMapping("/increase")
    public R sysCategoryIncrease(@RequestBody SysCategory sysCategory){
        sysCategoryService.increaseSysCategory(sysCategory);
        return RUtils.setResult(ResultCode.INCREASE_SUCCESS,"添加分类成功",null);
    }

    @GetMapping("/show")
    public R sysCategoryShow(@RequestParam("limit") int pageSize,@RequestParam ("page") int pageNum){
        PageInfo<SysCategory> pageInfo = sysCategoryService.queryAll(pageSize, pageNum);
        return RUtils.setResult(ResultCode.QUERY_SUCCESS,"查询分类成功",pageInfo);
    }

    @DeleteMapping("/delete")
    public R sysCategoryRemove(@RequestParam Long cid){
        sysCategoryService.removeSysCategory(cid);
        return RUtils.setResult(ResultCode.DELETE_SUCCESS,"删除成功",null);
    }

    @DeleteMapping("/deletes")
    public R sysCategoryRemoves(@RequestParam("ids") List<Long> cIds){
        sysCategoryService.removeSysCategoryByIds(cIds);
        return RUtils.setResult(ResultCode.DELETE_SUCCESS,"删除成功",null);
    }

    @GetMapping("/activate")
    public R sysCategoryActivate(@RequestParam("ids") List<Long> cIds){
        sysCategoryService.activateSysCategoryByIds(cIds);
        return RUtils.setResult(ResultCode.MODIFY_SUCCESS,"开启成功",null);
    }



}
