package com.qf.event.listener;

import com.qf.event.LoginEvent;
import com.qf.pojo.SysLoginInfo;
import com.qf.pojo.SysUserOnline;
import com.qf.service.SysLoginInfoService;
import com.qf.service.SysUserOnlineService;
import com.qf.service.SysUserInfoService;
import com.qf.utils.RequestUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * create by hhh7ox on 2022/5/26 17:03
 */
@Component
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
public class LoginListener {
    private SysUserInfoService sysUserInfoService;
    private SysUserOnlineService sysUserOnlineService;
    private SysLoginInfoService sysLoginInfoService;
    private ThreadPoolExecutor threadPoolExecutor;

    @Autowired
    public void setSysUserInfoService(SysUserInfoService sysUserInfoService) {
        this.sysUserInfoService = sysUserInfoService;
    }

    @Autowired
    public void setSysUserOnlineService(SysUserOnlineService sysUserOnlineService) {
        this.sysUserOnlineService = sysUserOnlineService;
    }

    @Autowired
    public void setSysLoginInfoService(SysLoginInfoService sysLoginInfoService) {
        this.sysLoginInfoService = sysLoginInfoService;
    }

    @Autowired
    public void setThreadPoolExecutor(ThreadPoolExecutor threadPoolExecutor) {
        this.threadPoolExecutor = threadPoolExecutor;
    }

    @EventListener
    public void onEvent(LoginEvent event) {
        System.out.println("一个登录事件发生");
        String username = event.getUsername();
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = servletRequestAttributes.getRequest();
        String sessionId = request.getSession().getId();
        Map<String, String> osAndBrowserInfo = RequestUtils.getOsAndBrowserInfo(request);
        String ip = RequestUtils.getRemoteHost(request);
        Date processDate = new Date();
        SysLoginInfo sysLoginInfo = new SysLoginInfo();
        SysUserOnline sysUserOnline = new SysUserOnline();

        CompletableFuture.runAsync(()->{

//            String locationByIp = RequestUtils.getLocationByIp(ip);
            sysLoginInfo.setLoginName(username);
            sysLoginInfo.setBrowser(osAndBrowserInfo.get("browser"));
            sysLoginInfo.setOs(osAndBrowserInfo.get("os"));
            sysLoginInfo.setLoginTime(processDate);
            sysLoginInfo.setIpaddr(ip);
//            sysLoginInfo.setLoginLocation(locationByIp);
            switch (event.getLoginType()) {
                case SUCCESS:
                    sysLoginInfo.setMsg("登录成功");
                    sysLoginInfo.setStatus("1");
                    break;
                case FAIL:
                    sysLoginInfo.setMsg("用户名密码错误");
                    sysLoginInfo.setStatus("0");
                    break;
            }

            BeanUtils.copyProperties(sysLoginInfo,sysUserOnline);
            sysUserOnline.setSessionId(sessionId);
            sysUserOnline.setStartTimestamp(processDate);
            sysUserOnline.setExpireTime(30L);

            sysLoginInfoService.increaseSysLoginInfo(sysLoginInfo);
            if (event.getLoginType()== LoginEvent.LoginType.SUCCESS){
                sysUserOnlineService.increaseOrModifySysUserOnline(sysUserOnline);
            }
        },threadPoolExecutor);

        CompletableFuture.runAsync(()->{
            if (event.getLoginType()== LoginEvent.LoginType.SUCCESS){
                sysUserInfoService.updateSysUserInfo(sysLoginInfo);
            }
        },threadPoolExecutor);

    }
}
