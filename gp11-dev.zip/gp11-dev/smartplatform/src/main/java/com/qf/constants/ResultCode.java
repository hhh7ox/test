package com.qf.constants;

/**
 * create by hhh7ox on 2022/5/25 19:13
 * 基础操作码
 * 00x 错误相关
 * 01x 查询相关
 * 02x 增加相关
 * 03x 更新相关
 * 04x 删除相关
 * 业务操作码
 * 05x 用户相关
 */
public interface ResultCode {
    String UNKNOWN_EXCEPTION = "000";
    String QUERY_SUCCESS = "011";
    String QUERY_FAIL = "012";
    String INCREASE_SUCCESS = "021";
    String INCREASE_FAIL = "022";
    String MODIFY_SUCCESS = "031";
    String MODIFY_FAIL = "032";
    String DELETE_SUCCESS = "041";
    String DELETE_FAIL = "042";
    String REGIST_SUCCESS = "051";
    String REGIST_ILLEGAL_NULL = "052";
    String REGIST_ILLEGAL_REPEAT = "053";
    String LOGIN_SUCCESS = "054";
    String LOGIN_ILLEGAL_NULL = "055";
    String LOGIN_USER_NOT_EXIST = "056";
    String DATA_ILLEGAL_NULL = "061";
    String DATA_ILLEGAL_REPEAT = "062";

}
