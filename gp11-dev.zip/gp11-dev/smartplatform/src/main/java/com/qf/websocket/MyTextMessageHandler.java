package com.qf.websocket;

import com.qf.event.CheckOnlineEvent;
import com.qf.event.SysDeviceCommandEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.PongMessage;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * create by hhh7ox on 2022/6/8 19:57
 */

@Component
@EnableAsync(proxyTargetClass = true)
public class MyTextMessageHandler extends TextWebSocketHandler {

    private static Map<String, WebSocketSession> allClient = new HashMap<>();
    private static Map<String, Long> heartBeatTime = new ConcurrentHashMap<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        String uri = session.getUri().toString();
        String deviceId = uri.substring(uri.lastIndexOf("/") + 1);
        session.getAttributes().put("deviceId", deviceId);
        heartBeatTime.put(deviceId, System.currentTimeMillis());
        allClient.put(deviceId, session);
        System.err.println("MyTextMessageHandler 中 afterConnectionEstablished 执行");
        super.afterConnectionEstablished(session);
    }


    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        System.err.println("MyTextMessageHandler 中 handleTextMessage执行 ---->" + message.getPayload());
        session.sendMessage(message);
        String deviceId = (String) session.getAttributes().get("deviceId");
        heartBeatTime.put(deviceId, System.currentTimeMillis());
        super.handleTextMessage(session, message);
    }

    @Override
    protected void handlePongMessage(WebSocketSession session, PongMessage message) throws Exception {
        super.handlePongMessage(session, message);
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        allClient.remove(session.getAttributes().get("name"));
        heartBeatTime.remove(session.getAttributes().get("deviceId"));
        super.afterConnectionClosed(session, status);
    }


    @EventListener
    @Async
    public void onEvent(SysDeviceCommandEvent sysDeviceCommandEvent) {
        System.err.println("sysDeviceCommandEvent 事件执行 " + sysDeviceCommandEvent);
        WebSocketSession session = allClient.get(sysDeviceCommandEvent.getDeviceId());
        if (session != null && session.isOpen()) {
            try {
                session.sendMessage(new TextMessage(sysDeviceCommandEvent.getCommand()));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @EventListener
    @Async
    public void onEvent(CheckOnlineEvent checkOnlineEvent){
        heartBeatTime.entrySet().forEach(entry->{
            String deviceId = entry.getKey();
            Long lastHeartTime = entry.getValue();
            if (System.currentTimeMillis() - lastHeartTime >= 60000) {
                WebSocketSession session = allClient.get(deviceId);
                if (session != null&&session.isOpen()) {
                    try {
                        session.close();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
    }


}
