package com.qf.dto;

/**
 * create by hhh7ox on 2022/5/25 19:18
 */
public class R {
    private String code;
    private String message;
    private Object data;

    public R(String code, String message, Object data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public R() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }


}
