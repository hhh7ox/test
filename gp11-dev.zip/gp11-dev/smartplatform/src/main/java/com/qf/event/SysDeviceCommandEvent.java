package com.qf.event;

/**
 * create by hhh7ox on 2022/6/9 16:30
 */

public class SysDeviceCommandEvent {
    private String deviceId;
    private String command;

    public SysDeviceCommandEvent(String deviceId, String command) {
        this.deviceId = deviceId;
        this.command = command;
    }

    public SysDeviceCommandEvent() {
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    @Override
    public String toString() {
        return "SysDeviceCommandEvent{" +
                "deviceId='" + deviceId + '\'' +
                ", command='" + command + '\'' +
                '}';
    }
}
