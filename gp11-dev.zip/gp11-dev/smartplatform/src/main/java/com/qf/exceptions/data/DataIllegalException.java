package com.qf.exceptions.data;

import com.qf.exceptions.BaseException;

/**
 * create by hhh7ox on 2022/5/26 10:50
 */
public class DataIllegalException extends BaseException {
    public DataIllegalException(String message, String code) {
        super(message, code);
    }
}
