package com.qf.controller;

import com.qf.constants.ResultCode;
import com.qf.dto.R;
import com.qf.pojo.SysScene;
import com.qf.service.SysSceneService;
import com.qf.utils.RUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * create by hhh7ox on 2022/6/7 19:23
 */

@RestController
@RequestMapping("/scene")
public class SysSceneController {
    private SysSceneService sysSceneService;

    @Autowired
    public void setSysSceneService(SysSceneService sysSceneService) {
        this.sysSceneService = sysSceneService;
    }

    @PostMapping("/increase")
    public R increaseSysScene(@RequestBody SysScene sysScene){
        sysSceneService.increaseSysScene(sysScene);
        return RUtils.setResult(ResultCode.INCREASE_SUCCESS,"添加场景成功",null);
    }
}
