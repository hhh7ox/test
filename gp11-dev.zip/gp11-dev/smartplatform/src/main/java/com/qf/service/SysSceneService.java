package com.qf.service;

import com.qf.pojo.SysScene;

/**
 * create by hhh7ox on 2022/6/7 19:27
 */
public interface SysSceneService {
    void increaseSysScene(SysScene sysScene);
}
