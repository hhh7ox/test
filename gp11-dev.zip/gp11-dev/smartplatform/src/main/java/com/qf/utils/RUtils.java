package com.qf.utils;

import com.qf.constants.ResultCode;
import com.qf.dto.R;

/**
 * create by hhh7ox on 2022/5/25 19:23
 */
public class RUtils {
    public static R setResult(String code, String message, Object data) {
        return new R(code, message, data);
    }

    public static R getRegistSuccess() {
        return setResult(ResultCode.REGIST_SUCCESS, "注册成功", null);
    }


    public static R getLoginSuccess() {
        return setResult(ResultCode.LOGIN_SUCCESS,"登录成功",null);
    }

    public static R getException( String message) {
        return setResult(ResultCode.UNKNOWN_EXCEPTION,message,null);
    }

    public static R getBaseException(String code, String message) {
        return setResult(code,message,null);
    }
}
