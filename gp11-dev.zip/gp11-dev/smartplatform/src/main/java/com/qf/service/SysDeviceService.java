package com.qf.service;

import com.github.pagehelper.PageInfo;
import com.qf.dto.SysDeviceDto;
import com.qf.pojo.SysCategory;
import com.qf.pojo.SysDevice;

/**
 * create by hhh7ox on 2022/6/7 16:47
 */
public interface SysDeviceService {
    void increaseSysDevice(SysDeviceDto sysDeviceDto);

    void modifySysDeviceStatus(String deviceId, Integer status);

    SysDevice querySysDeviceById(String deviceId);

    void bindUserAndScene(SysDevice sysDevice,Long sceneId);

    PageInfo<SysDevice> queryAll(int pageSize, int pageNum);

    void sendCommand(String deviceId, String command);


}
