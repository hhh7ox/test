package com.qf.service;

import com.qf.pojo.SysUserOnline;

/**
 * create by hhh7ox on 2022/5/26 17:45
 */

public interface SysUserOnlineService {
    void increaseOrModifySysUserOnline(SysUserOnline sysUserOnline);
}
