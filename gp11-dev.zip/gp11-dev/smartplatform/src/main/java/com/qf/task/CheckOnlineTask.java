package com.qf.task;

import com.qf.event.CheckOnlineEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * create by hhh7ox on 2022/6/9 22:08
 */

@EnableScheduling
@Component
public class CheckOnlineTask {
    private ApplicationContext context;

    @Autowired
    public void setContext(ApplicationContext context) {
        this.context = context;
    }

    @Scheduled(cron = "0/20 * * * * ?")
    public void checkOnline(){
        System.err.println("CheckOnlineTask 中 checkOnline 执行");
        context.publishEvent(new CheckOnlineEvent());
    }
}
