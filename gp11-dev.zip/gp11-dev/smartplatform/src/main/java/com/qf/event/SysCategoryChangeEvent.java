package com.qf.event;

/**
 * create by hhh7ox on 2022/6/6 19:45
 */


public class SysCategoryChangeEvent {
}
