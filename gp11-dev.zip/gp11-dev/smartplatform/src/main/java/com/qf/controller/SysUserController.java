package com.qf.controller;

import com.qf.dto.R;
import com.qf.dto.SysUserDto;
import com.qf.pojo.SysUserInfo;
import com.qf.service.SysUserInfoService;
import com.qf.utils.RUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * create by hhh7ox on 2022/5/25 19:48
 */

@RestController
@RequestMapping("/sysUser")
public class SysUserController {
    private SysUserInfoService sysUserService;

    @Autowired
    public void setSysUserService(SysUserInfoService sysUserService){
        this.sysUserService = sysUserService;
    }
    @PostMapping("/regist")
    public R registSysUserInfo(@RequestBody SysUserDto sysUserDto){

        sysUserService.increaseSysUserInfo(sysUserDto);

        return RUtils.getRegistSuccess();
    }

    @PostMapping("/login")
    public R loginSysUserInfo(@RequestBody SysUserDto sysUserDto, HttpServletRequest request){
        SysUserInfo sysUserInfo = sysUserService.querySysUserInfo(sysUserDto);
        request.getSession().setAttribute("sysUserInfo",sysUserInfo);
        return RUtils.getLoginSuccess();
    }
}
