package com.qf.interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.qf.constants.ResultCode;
import com.qf.pojo.SysUserInfo;
import com.qf.utils.RUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * create by hhh7ox on 2022/6/6 21:46
 */

@Controller
public class LoginInterceptor implements HandlerInterceptor {
    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        SysUserInfo sysUserInfo = (SysUserInfo) request.getSession().getAttribute("sysUserInfo");
        if (sysUserInfo == null) {
            response.setContentType("application/json;charset=utf-8");
            response.getWriter().write(objectMapper.writeValueAsString(RUtils.setResult(ResultCode.LOGIN_ILLEGAL_NULL, "用户需要登录", null)));
        }
        return sysUserInfo != null;
    }
}
