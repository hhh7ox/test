package com.qf.pojo;


import java.util.Date;

public class SysMenu {

  private Long menuId;
  private String menuName;
  private Long parentId;
  private Long orderNum;
  private String url;
  private String target;
  private String menuType;
  private String visible;
  private String enable;
  private String isRefresh;
  private String perms;
  private String icon;
  private String createBy;
  private java.util.Date createTime;
  private String updateBy;
  private java.util.Date updateTime;
  private String remark;

  public SysMenu() {
  }

  public SysMenu(Long menuId, String menuName, Long parentId, Long orderNum, String url, String target, String menuType, String visible, String enable, String isRefresh, String perms, String icon, String createBy, Date createTime, String updateBy, Date updateTime, String remark) {
    this.menuId = menuId;
    this.menuName = menuName;
    this.parentId = parentId;
    this.orderNum = orderNum;
    this.url = url;
    this.target = target;
    this.menuType = menuType;
    this.visible = visible;
    this.enable = enable;
    this.isRefresh = isRefresh;
    this.perms = perms;
    this.icon = icon;
    this.createBy = createBy;
    this.createTime = createTime;
    this.updateBy = updateBy;
    this.updateTime = updateTime;
    this.remark = remark;
  }

  public Long getMenuId() {
    return menuId;
  }

  public void setMenuId(Long menuId) {
    this.menuId = menuId;
  }


  public String getMenuName() {
    return menuName;
  }

  public void setMenuName(String menuName) {
    this.menuName = menuName;
  }


  public Long getParentId() {
    return parentId;
  }

  public void setParentId(Long parentId) {
    this.parentId = parentId;
  }


  public Long getOrderNum() {
    return orderNum;
  }

  public void setOrderNum(Long orderNum) {
    this.orderNum = orderNum;
  }


  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }


  public String getTarget() {
    return target;
  }

  public void setTarget(String target) {
    this.target = target;
  }


  public String getMenuType() {
    return menuType;
  }

  public void setMenuType(String menuType) {
    this.menuType = menuType;
  }


  public String getVisible() {
    return visible;
  }

  public void setVisible(String visible) {
    this.visible = visible;
  }


  public String getEnable() {
    return enable;
  }

  public void setEnable(String enable) {
    this.enable = enable;
  }


  public String getIsRefresh() {
    return isRefresh;
  }

  public void setIsRefresh(String isRefresh) {
    this.isRefresh = isRefresh;
  }


  public String getPerms() {
    return perms;
  }

  public void setPerms(String perms) {
    this.perms = perms;
  }


  public String getIcon() {
    return icon;
  }

  public void setIcon(String icon) {
    this.icon = icon;
  }


  public String getCreateBy() {
    return createBy;
  }

  public void setCreateBy(String createBy) {
    this.createBy = createBy;
  }


  public java.util.Date getCreateTime() {
    return createTime;
  }

  public void setCreateTime(java.util.Date createTime) {
    this.createTime = createTime;
  }


  public String getUpdateBy() {
    return updateBy;
  }

  public void setUpdateBy(String updateBy) {
    this.updateBy = updateBy;
  }


  public java.util.Date getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(java.util.Date updateTime) {
    this.updateTime = updateTime;
  }


  public String getRemark() {
    return remark;
  }

  public void setRemark(String remark) {
    this.remark = remark;
  }

  @Override
  public String toString() {
    return "SysMenu{" +
            "menuId=" + menuId +
            ", menuName='" + menuName + '\'' +
            ", parentId=" + parentId +
            ", orderNum=" + orderNum +
            ", url='" + url + '\'' +
            ", target='" + target + '\'' +
            ", menuType='" + menuType + '\'' +
            ", visible='" + visible + '\'' +
            ", enable='" + enable + '\'' +
            ", isRefresh='" + isRefresh + '\'' +
            ", perms='" + perms + '\'' +
            ", icon='" + icon + '\'' +
            ", createBy='" + createBy + '\'' +
            ", createTime=" + createTime +
            ", updateBy='" + updateBy + '\'' +
            ", updateTime=" + updateTime +
            ", remark='" + remark + '\'' +
            '}';
  }
}
