package com.qf.utils;

import com.qf.pojo.SysUserInfo;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * create by hhh7ox on 2022/6/6 11:57
 */
public class SecurityUtils {
    public static SysUserInfo getSysUserInfo(){
        return (SysUserInfo)((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getSession().getAttribute("sysUserInfo");
    }
}
