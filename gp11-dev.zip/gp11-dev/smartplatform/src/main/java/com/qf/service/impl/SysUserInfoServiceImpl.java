package com.qf.service.impl;

import com.qf.constants.ResultCode;
import com.qf.dto.SysUserDto;
import com.qf.event.LoginEvent;
import com.qf.exceptions.login.LoginNoSuchSysUserInfoException;
import com.qf.exceptions.login.LoginSysUserInfoIllegalException;
import com.qf.exceptions.regist.RegistSysUserInfoIllegalException;
import com.qf.mapper.SysUserInfoMapper;
import com.qf.pojo.SysLoginInfo;
import com.qf.pojo.SysUserInfo;
import com.qf.service.SysUserInfoService;
import com.qf.utils.JudgeUtils;
import com.qf.utils.RandomUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import java.util.Date;

/**
 * create by hhh7ox on 2022/5/25 19:44
 */

@Service
@Transactional
public class SysUserInfoServiceImpl implements SysUserInfoService {
    private SysUserInfoMapper sysUserInfoMapper;
    private ApplicationContext context;

    @Autowired
    public void setContext(ApplicationContext context) {
        this.context = context;
    }

    @Autowired
    public void setSysUserMapper(SysUserInfoMapper sysUserInfoMapper) {
        this.sysUserInfoMapper = sysUserInfoMapper;
    }

    public void increaseSysUserInfo(SysUserDto sysUserDto) {
        SysUserInfo sysUserInfo = new SysUserInfo();
        Assert.isTrue(!JudgeUtils.isEmpty(sysUserDto), () -> {
            throw new RegistSysUserInfoIllegalException("注册信息存在空值", ResultCode.REGIST_ILLEGAL_NULL);
        });
        Assert.isNull(sysUserInfoMapper.selectByUsername(sysUserDto), () -> {
            throw new RegistSysUserInfoIllegalException("用户名已注册", ResultCode.REGIST_ILLEGAL_REPEAT);
        });
        Assert.isNull(sysUserInfoMapper.selectByPhone(sysUserDto), () -> {
            throw new RegistSysUserInfoIllegalException("手机号已注册", ResultCode.REGIST_ILLEGAL_REPEAT);
        });
        Assert.isNull(sysUserInfoMapper.selectByEmail(sysUserDto), () -> {
            throw new RegistSysUserInfoIllegalException("邮箱已注册", ResultCode.REGIST_ILLEGAL_REPEAT);
        });
        BeanUtils.copyProperties(sysUserDto, sysUserInfo);
        sysUserInfo.setType(1L);
        sysUserInfo.setStatus(1L);
        sysUserInfo.setCreateBy(sysUserInfo.getUsername());
        sysUserInfo.setCreateTime(new Date());
        String[] passwordAndSalt = RandomUtils.getMD5WithRandomSalt(sysUserInfo.getPassword());
        sysUserInfo.setPassword(passwordAndSalt[0]);
        sysUserInfo.setPwdSalt(passwordAndSalt[1]);
        sysUserInfo.setRemark("普通用户");

        sysUserInfoMapper.insertSysUser(sysUserInfo);

    }

    public SysUserInfo querySysUserInfo(SysUserDto sysUserDto) {

        Assert.isTrue(!JudgeUtils.isEmpty(sysUserDto, "username", "password"), () -> {
            context.publishEvent(new LoginEvent(LoginEvent.LoginType.FAIL,sysUserDto.getUsername()));
            throw new LoginSysUserInfoIllegalException("登录信息不能为空", ResultCode.LOGIN_ILLEGAL_NULL);
        });
        SysUserInfo sysUserInfo = sysUserInfoMapper.selectByUsername(sysUserDto);
        Assert.notNull(sysUserInfo, () -> {
            context.publishEvent(new LoginEvent(LoginEvent.LoginType.FAIL,sysUserDto.getUsername()));
            throw new LoginNoSuchSysUserInfoException("用户不存在", ResultCode.LOGIN_USER_NOT_EXIST);
        });
        System.out.println(sysUserInfo);
        String sysUserDtoMD5 = RandomUtils.getMD5WithSalt(sysUserDto.getPassword(),sysUserInfo.getPwdSalt());
        Assert.isTrue(sysUserInfo.getPassword().equals(sysUserDtoMD5), () -> {
            context.publishEvent(new LoginEvent(LoginEvent.LoginType.FAIL,sysUserDto.getUsername()));
            throw new LoginNoSuchSysUserInfoException("用户名或密码错误", ResultCode.LOGIN_USER_NOT_EXIST);
        });

        context.publishEvent(new LoginEvent(LoginEvent.LoginType.SUCCESS,sysUserDto.getUsername()));
        return sysUserInfo;
    }

    @Override
    public void updateSysUserInfo(SysLoginInfo sysLoginInfo) {
        sysUserInfoMapper.updateSysUserInfoByUsername(sysLoginInfo);

    }


}
