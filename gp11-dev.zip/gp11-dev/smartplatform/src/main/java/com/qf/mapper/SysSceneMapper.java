package com.qf.mapper;

import com.qf.pojo.SysScene;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * create by hhh7ox on 2022/6/7 19:40
 */

public interface SysSceneMapper {
    void insertSysScene(SysScene sysScene);

    @Select("select * from sys_scene where create_by=#{uId}")
    List<SysScene> selectAllByUid(Long uId);
}
