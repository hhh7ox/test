package com.qf.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.qf.cache.SysCategoryCache;
import com.qf.constants.ResultCode;
import com.qf.event.SysCategoryChangeEvent;
import com.qf.exceptions.data.DataIllegalException;
import com.qf.exceptions.login.LoginSysUserInfoIllegalException;
import com.qf.mapper.SysCategoryMapper;
import com.qf.pojo.SysCategory;
import com.qf.pojo.SysUserInfo;
import com.qf.service.SysCategoryService;
import com.qf.utils.JudgeUtils;
import com.qf.utils.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * create by hhh7ox on 2022/6/6 11:15
 */
@Service
public class SysCategoryServiceImpl implements SysCategoryService {
    private SysCategoryMapper sysCategoryMapper;
    private SysCategoryCache sysCategoryCache;
    private ApplicationContext context;

    @Autowired
    public void setContext(ApplicationContext context) {
        this.context = context;
    }

    @Autowired
    public void setSysCategoryMapper(SysCategoryMapper sysCategoryMapper) {
        this.sysCategoryMapper = sysCategoryMapper;
    }

    @Autowired
    public void setSysCategoryCache(SysCategoryCache sysCategoryCache) {
        this.sysCategoryCache = sysCategoryCache;
    }

    @Override
    public void increaseSysCategory(SysCategory sysCategory) {
        String[] params = {"categoryName", "txCommand", "rxCommand", "commandName"};
        SysUserInfo sysUserInfo = SecurityUtils.getSysUserInfo();
        Assert.isTrue(JudgeUtils.isEmpty(sysCategory, params), () -> {
            throw new DataIllegalException("数据不完整", ResultCode.DATA_ILLEGAL_NULL);
        });
        Assert.notNull(sysUserInfo, () -> {
            throw new LoginSysUserInfoIllegalException("用户登录信息不存在", ResultCode.LOGIN_ILLEGAL_NULL);
        });
        sysCategory.setCreateBy(sysUserInfo.getName());
        sysCategory.setCreateTime(new Date());
        sysCategoryMapper.insertSysCategory(sysCategory);
        context.publishEvent(new SysCategoryChangeEvent());

    }

    @Override
    public PageInfo<SysCategory> queryAll(int pageSize, int pageNum) {
        List<SysCategory> sysCategoryList = sysCategoryCache.getSysCategoryList(false);
        PageHelper.startPage(pageSize, pageNum);
        List<SysCategory> result = sysCategoryList.stream()
                .skip((long) (pageNum - 1) * pageSize)
                .limit(pageSize)
                .collect(Collectors.toList());
        PageInfo<SysCategory> pageInfo = new PageInfo<>(result);
        pageInfo.setTotal(result.size());
        return pageInfo;
    }

    @Override
    public void removeSysCategory(Long cId){
        SysUserInfo sysUserInfo = SecurityUtils.getSysUserInfo();
        Assert.notNull(sysUserInfo,()->{
            throw new LoginSysUserInfoIllegalException("用户登录信息为空 不能进行修改",ResultCode.DELETE_FAIL);
        });
        sysCategoryMapper.deleteByCid(cId,new Date(),sysUserInfo.getName());
    }

    @Override
    public void removeSysCategoryByIds(List<Long> cIds) {
        SysUserInfo sysUserInfo = SecurityUtils.getSysUserInfo();
        Assert.notNull(sysUserInfo,()->{
            throw new LoginSysUserInfoIllegalException("用户登录信息为空 不能进行删除",ResultCode.DELETE_FAIL);
        });
        sysCategoryMapper.deleteByCids(cIds,new Date(),sysUserInfo.getName());
    }

    @Override
    public void activateSysCategoryByIds(List<Long> cIds) {
        SysUserInfo sysUserInfo = SecurityUtils.getSysUserInfo();
        Assert.notNull(sysUserInfo,()->{
            throw new LoginSysUserInfoIllegalException("用户登录信息为空 不能进行开启",ResultCode.DELETE_FAIL);
        });
        sysCategoryMapper.updateStatusByIds(cIds,new Date(),sysUserInfo.getName());
    }

    @Override
    public String queryTxCommandByCid(Long cId) {
        return sysCategoryMapper.selectTxCommandByCid(cId);
    }


}
