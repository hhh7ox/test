package com.qf.mapper;

import com.qf.pojo.SysMenu;

import java.util.List;

/**
 * create by hhh7ox on 2022/6/8 20:19
 */

public interface SysMenuMapper {

    List<SysMenu> selectAll();


}
