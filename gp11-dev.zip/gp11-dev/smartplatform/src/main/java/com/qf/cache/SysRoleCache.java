package com.qf.cache;

/**
 * create by hhh7ox on 2022/6/11 17:21
 */
public class SysRoleCache {
    public Object get(Long roleId) {
        return null;
    }
}
