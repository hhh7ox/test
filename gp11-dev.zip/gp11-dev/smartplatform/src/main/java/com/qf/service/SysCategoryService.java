package com.qf.service;

import com.github.pagehelper.PageInfo;
import com.qf.pojo.SysCategory;

import java.util.List;

/**
 * create by hhh7ox on 2022/6/6 11:14
 */
public interface SysCategoryService {

    void increaseSysCategory(SysCategory sysCategory);

    PageInfo<SysCategory> queryAll(int limit,int page);

    void removeSysCategory(Long cId);

    void removeSysCategoryByIds(List<Long> cIds);

    void activateSysCategoryByIds(List<Long> cIds);

    String queryTxCommandByCid(Long cId);
}
