package com.qf.service;

/**
 * create by hhh7ox on 2022/5/19 19:27
 */
public interface UserService {
    void addUser(String name);

    String updateUser(String name);
}
