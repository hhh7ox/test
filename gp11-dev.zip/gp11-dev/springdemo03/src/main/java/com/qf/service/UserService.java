package com.qf.service;

/**
 * create by hhh7ox on 2022/5/18 16:48
 */

public interface UserService {
    void addUser();
}
