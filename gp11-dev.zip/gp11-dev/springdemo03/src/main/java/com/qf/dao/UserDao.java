package com.qf.dao;

/**
 * create by hhh7ox on 2022/5/18 16:47
 */

public interface UserDao {
    void insertUser();
}
