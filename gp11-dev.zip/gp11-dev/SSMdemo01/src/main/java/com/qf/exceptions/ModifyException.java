package com.qf.exceptions;

/**
 * create by hhh7ox on 2022/5/24 21:42
 */
public class ModifyException extends BaseException{
    public ModifyException(String message, Integer code) {
        super(message, code);
    }
}
