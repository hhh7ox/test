package com.qf.exceptions;

/**
 * create by hhh7ox on 2022/5/24 19:10
 */
public class IncreaseException extends BaseException{
    public IncreaseException(String message, Integer code) {
        super(message, code);
    }
}
