package com.qf.service;

/**
 * create by hhh7ox on 2022/5/19 10:55
 */
public interface UserService {
    void addUser(String name);
    String modifyUser(String name);
}
