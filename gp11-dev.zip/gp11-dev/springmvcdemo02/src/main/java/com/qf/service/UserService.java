package com.qf.service;

import com.qf.pojo.User;

/**
 * create by hhh7ox on 2022/5/20 17:26
 */
public interface UserService {
    User findUserById(Long id);
}
